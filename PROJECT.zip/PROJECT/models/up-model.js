var db = require('./db');

module.exports ={
	
	insert: function(user, callback){

		var sql = "UPDATE property SET price = ROUND(price/1.05,2) where id = '"+user.id+"'";

		
		console.log(sql);

		db.execute(sql, function(status){
			if(status){
				console.log("Query Executed!");
				callback(true);
			}else{				
				callback(false);
			}
		});
	}

}