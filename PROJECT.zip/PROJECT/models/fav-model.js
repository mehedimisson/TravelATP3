var db = require('./db');

module.exports ={
	favorProp: function(favInfo, callback){
		
		var sql1 = "SELECT * FROM favprop WHERE u_name='"+favInfo.user+"' and p_id="+favInfo.prop_id+"";
		var sql2 = "INSERT INTO favprop VALUES (null,'"+favInfo.user+"',"+favInfo.prop_id+",'"+favInfo.prop_name+"',p)";

		db.getResult(sql1, function(result){
			if(result.length > 0){
				callback(true,1);
			}else{
				db.execute(sql2, function(status){
					if(status){
						callback(true,0);
					}else{
						callback(false,0);
					}
				});
			}
		});		
	},
	favorAgent: function(favInfo, callback){
		
		var sql1 = "SELECT * FROM favagent WHERE u_name='"+favInfo.user+"' and a_id="+favInfo.prop_id+"";
		var sql2 = "INSERT INTO favagent VALUES (null,'"+favInfo.user+"',"+favInfo.prop_id+",'"+favInfo.prop_name+"')";

		db.getResult(sql1, function(result){
			if(result.length > 0){
				callback(true,1);
			}else{
				db.execute(sql2, function(status){
					if(status){
						callback(true,0);
					}else{
						callback(false,0);
					}
				});
			}
		});		
	}
}