var db = require('./db');

module.exports ={
	
	getById: function(id, callback){
		var sql = "select * from reqbook where rid=?";
		db.getResult(sql, [id], function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},
	getAll:function(callback){
		var sql = "select * from reqbook";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(null);
			}
		});
	},
	insert: function(user, callback){
		var sql = "INSERT IGNORE INTO accbook (cusid,cusname,plname,duration,cusemail,price) SELECT reqbook.cid,reqbook.cname,reqbook.place,reqbook.duration,reqbook.email,reqbook.price FROM reqbook WHERE reqbook.rid = ?";
		var sql2 = "delete from reqbook where rid=?";
		
		db.execute(sql, [user.id], function(status){
			db.execute(sql2, [id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}		
		});
	});		
	},
	delete: function(id, callback){
		var sql = "delete from reqbook where rid=?";
		db.execute(sql, [id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	update: function(user, callback){
		var sql = "update product set pname=?, quantity=?, price=? where id=?";
		db.execute(sql, [user.pname, user.quantity, user.price, user.id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	}
}