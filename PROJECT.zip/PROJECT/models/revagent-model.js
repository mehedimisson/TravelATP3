var db = require('./db');

module.exports ={
	insert: function(review, callback){
		
		var sql = "INSERT INTO revcustomer VALUES (null,'"+review.user+"',"+review.prop_id+",'"+review.prop_name+"',"+review.score+")";

		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	update: function(uprev, callback){
		var sql = "UPDATE revcustomer SET rating="+uprev.score+" WHERE u_name='"+uprev.user+"' and a_id='"+uprev.prop_id+"'";

		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getReview: function(rev, callback){
		var sql = "SELECT COUNT(rating)\"totalUsers\" FROM revcustomer WHERE a_name='"+rev.name+"'";
		var sql2 = "SELECT SUM(rating)\"sumReviews\" FROM revcustomer WHERE a_name='"+rev.name+"'";
		var sql3 = "SELECT rating FROM revcustomer WHERE username = '"+rev.u_name+"' and cusname='"+rev.name+"'";
		
		db.getResult(sql, function(result){
			db.getResult(sql2, function(result2){
				db.getResult(sql3, function(result3){
					if(result[0] != null){
						callback(result[0],result2[0],result3[0]);
					}else{
						callback(null);
					}
				});
			});
		});
	}
}