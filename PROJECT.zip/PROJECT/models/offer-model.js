var db = require('./db');

module.exports ={
	
	insert: function(user, callback){

		var sql = "INSERT INTO property (name, price, tour_id, summary) VALUES('"+user.name+"','"+user.price+"','"+user.tid+"','"+user.sm+"')";
		
		console.log(sql);

		db.execute(sql, function(status){
			if(status){
				console.log("Query Executed!");
				callback(true);
			}else{				
				callback(false);
			}
		});
	}

}