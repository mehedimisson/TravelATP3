var db = require('./db');

module.exports ={

	getByProp: function(id, callback){
		var sql = "select * from property where id="+id;
		db.getResult(sql, function(result){

			if(result.length > 0){
				callback(result);
			}else{
				callback(null);
			}
		});
	},
	getById: function(id, callback){
		var sql = "select * from property where tour_id="+id;
		db.getResult(sql, function(result){

			if(result.length > 0){
				callback(result);
			}else{
				callback(null);
			}
		});
	},
	delete: function(id, callback){
		var sql = "delete from property where id="+id;
		db.execute(sql, function(status){
			if(status){			
				callback(true);
			}else{				
				callback(false);
			}
		});
	},
	getAll:function(callback){
		var sql = "select * from property";
		db.getResult(sql, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(null);
			}
		});
	}

}