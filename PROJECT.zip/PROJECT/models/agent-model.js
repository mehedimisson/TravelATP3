var db = require('./db');

module.exports ={

	getById: function(id, callback){
		var sql = "select * from customer where cusid="+id;
		db.getResult(sql, function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},
	getAll:function(callback){
		var sql = "select * from customer";
		db.getResult(sql, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(null);
			}
		});
	}

}