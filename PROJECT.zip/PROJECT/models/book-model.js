var db = require('./db');

module.exports ={

	getById: function(id, callback){
		var sql = "select * from accbook where id="+id;

		db.getResult(sql, function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},
	getAll:function(username, callback){
		var sql = "select * from accbook where username='"+username+"' order by id desc";

		db.getResult(sql, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(0);
			}
		});
	}

}