var db = require('./db');

module.exports ={
	
	insert: function(user, callback){

		var sql = "INSERT INTO agent (name, username, password, email, phone,address,status) VALUES('"+
					user.name+"','"+user.uname+"','"+user.password+"','"+user.eml+"','"+user.phn+"','"+user.add+"','active')";
		
		console.log(sql);

		db.execute(sql, function(status){
			if(status){
				console.log("Query Executed!");
				callback(true);
			}else{				
				callback(false);
			}
		});
	}

}