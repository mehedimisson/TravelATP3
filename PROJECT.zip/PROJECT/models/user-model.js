var db = require('./db');


module.exports ={
	getById: function(user, callback){
		var sql = "select * from agent where username='"+user+"'";
		db.getResult(sql, function(result){

			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},
	verifyPassword: function(user, callback){
		var sql = "select * from agent where username='"+user.uname+"' and password='"+user.password+"'";

		db.getResult(sql, function(result){

			if(result.length > 0){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	confirmNewPassword: function(user, callback){
		var sql = "UPDATE agent SET password='"+user.password+"' WHERE username='"+user.uname+"'";
		// console.log(sql);
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	validate: function(user, callback){
		var sql = "select * from agent where username='"+user.uname+"' and password='"+user.password+"' and status='active'";

		db.getResult(sql, function(result){

			if(result.length > 0){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getAll:function(callback){
		var sql = "select * from agent";
		db.getResult(sql, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(null);
			}
		});
	},
	deactivate: function(user, callback){

		var sql = "UPDATE agent SET status='deactivated' WHERE username='"+user+"'";
		
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	update: function(user, callback){
		
		var sql = "UPDATE agent SET name='"+user.name+"',phone='"+user.phn+"',email='"+user.eml+"' WHERE username='"+user.uname+"'";

		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	}
}/*



module.exports ={
	getById: function(id, callback){
		var sql = "select * from agent where id="+id;
		db.getResult(sql, function(result){

			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},
	getByUname: function(uname, callback){
		var sql = "select * from agent where username='"+uname+"'";
		db.getResult(sql, function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},
	validate: function(user, callback){
		var sql = "select * from agent where username='"+user.uname+"' and password='"+user.password+"'";

		db.getResult(sql, function(result){

			if(result.length > 0){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getAll:function(callback){
		var sql = "select * from agent";
		db.getResult(sql, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(null);
			}
		});
	},
	insert: function(user, callback){
		var sql = "insert ...........";
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	delete: function(user, callback){
		var sql = "delete from user ...........";
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	update: function(user, callback){
		var sql = "update set ...........";
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	}
}
*/
