var express 	= require('express');
var router 		= express.Router();
var bookModel   = require.main.require('./models/book-model');

router.get('/', function(req, res){
	console.log('history page requested!');
	user = req.session.curr_uname;

	bookModel.getAll(user,function(results){
		if(results.length > 0){
			console.log(results);
			res.render('history/index', {historylist: results});
		}else{
			res.render('history/index', {historylist: results});
			console.log(results);
		}
	});

});


module.exports = router;

