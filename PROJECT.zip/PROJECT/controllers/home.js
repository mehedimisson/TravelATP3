var express 	= require('express');
var router 		= express.Router();
var userModel   = require.main.require('./models/user-model');
var prodModel   = require.main.require('./models/prod-model');
//var offModel   = require.main.require('./models/off-model');

router.get('/', function(req, res){
			res.render('home/index');

});

router.get('/alluser', function(req, res){

	userModel.getAll(function(results){
		if(results.length > 0){
			res.render('home/alluser', {userlist: results});
		}else{
			res.send('invalid username/password');
		}
	});
})

router.get('/prod_edit/:id', function(req, res){
	
	prodModel.getById(req.params.id, function(result){
		res.render('home/prod_edit', {prod: result});
	});
})

router.get('/prod_delete/:id', function(req, res){
	
	prodModel.getById(req.params.id, function(result){
		res.render('home/prod_delete', {prod: result});
	});
})

module.exports = router;

