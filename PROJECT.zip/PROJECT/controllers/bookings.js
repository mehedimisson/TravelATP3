var express 	= require('express');
var router 		= express.Router();
var bookModel	= require.main.require('./models/book-model');

router.get('/', function(req, res){
	console.log('Booking page requested!');
	bookModel.getAll(req.session.curr_uname, function(results){
		if(results.length > 0){
			res.render('bookings/index', {bookinglist: results});
		}else{
			res.send("Wrong index");
		}
	});

});

router.post('/pay', function(req, res){

	req.session.agentId = req.body.viewBtn;
	req.session.agentname = req.body.hidval;

	res.render('tours/payment');
});

router.post('/thanks', function(req, res){
		
		var booking ={
			uname : req.session.curr_uname,
			tid : req.session.tourId,
			tname : req.session.tourname,
			pid : req.session.propId,
			pname : req.session.propname,
			aid : req.session.agentId,
			aname : req.session.agentname,
			date : "CURRENT_DATE",
			p_price: req.session.prop_price,
			p_method: req.body.selected_pm
		};

		bookModel.insert(booking, function(status){
			if(status){
				res.render('thankspage');
			}else{
				res.send("Wrong booking");
			}
		});
});

module.exports = router;

