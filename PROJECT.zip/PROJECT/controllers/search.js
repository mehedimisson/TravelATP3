var express 	= require('express');
var router 		= express.Router();
var db 			= require.main.require('./models/db');
var bodyparser = require('body-parser');
var urlencodedparser = bodyparser.urlencoded({extended:false})


router.get('/', function(req, res){
	console.log('Search Page Loaded!');
	res.render('search/index');
});

router.get('/searching', urlencodedparser, function(req, res){
	
	// res.send("<h1>"+req.query.sv+"</h1>");
	
	var sql = "select cusid,cusname,cuspic from customer where cusname LIKE '%"+req.query.sv+"%'";
	console.log(sql);
	console.log();
	db.getResult(sql, function(result){
		if(result.length > 0)
		{
			console.log(result);
			res.send(result);
		}
		else
		{
			res.send("");
		}
	});	


	
});

module.exports = router;

