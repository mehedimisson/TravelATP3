var express 	= require('express');
var router 		= express.Router();
//var agentModel	= require.main.require('./models/agent-model');
var revpropModel	= require.main.require('./models/revprop-model');
var propModel	= require.main.require('./models/prop-model');
var tourModel	= require.main.require('./models/tour-model');
var favModel	= require.main.require('./models/fav-model');

router.get('/', function(req, res){
	
	console.log('Property Details page requested!');

});

router.post('/', function(req, res){

		var p_id = req.body.viewBtn;
		var fav = req.body.favBtn;
		var rev = req.body.reviewBtn;
		var back = req.body.backBtn;
		var updateRev = req.body.updateRev;

		var score = req.body.rev_num;
		req.session.propId = p_id;
		req.session.propname = req.body.hidval;
		req.session.prop_price = req.body.hidprice;

		if(p_id != null)
		{
			propModel.delete(p_id,function(status){
				if(status){

					res.redirect('/tours');
				}else{
					res.send("Wrong index");
				}
			});
	
		}
		else if(fav != null)
		{
			var favInfo = {
				user: req.session.curr_uname,
				prop_id: fav,
				prop_name: req.session.propname
			};
			favModel.favorProp( favInfo, function(status,isFavored){
				if(status){
					propModel.getByProp(fav, function(results){
						if(results.length > 0){

							var revCheck = {
								name: results[0].name,
								u_name: req.session.curr_uname
							}

							console.log(isFavored);
							revpropModel.getReview( revCheck, function(rev_COUNT,rev_SUM,rev_USER){
								if(rev_COUNT.totalUsers != 0){
									var cal_score = rev_SUM.sumReviews/rev_COUNT.totalUsers;
									cal_score = cal_score.toFixed(1);

									var temp1;
									if(rev_USER == null)
									{
										temp1 = 0;
									}
									else
									{
										temp1 = rev_USER.rating;
									}
			
									res.render('tours/propDetails', {prop: results,rating: cal_score,userTotal: rev_COUNT.totalUsers,userRev: temp1,isFav: isFavored});
								}else{
									res.render('tours/propDetails', {prop: results,rating: 0,userTotal: rev_COUNT.totalUsers,userRev: 0,isFav: isFavored});
								}
							});
			
						}else{
							res.send("Wrong propDetails");
						}
					});	
				}else{
					res.send("Wrong Favor");
				}
			});
		}
		else if(rev != null)
		{
			var review = {
				user: req.session.curr_uname,
				prop_id: rev,
				prop_name: req.session.propname,
				score: score
			};
			revpropModel.insert(review, function(status){
				if(status){
					propModel.getByProp(rev, function(results){
						if(results.length > 0){
			
							var revCheck = {
								name: results[0].name,
								u_name: req.session.curr_uname
							}
			
							revpropModel.getReview( revCheck, function(rev_COUNT,rev_SUM,rev_USER){
								if(rev_COUNT.totalUsers != 0){
									var cal_score = rev_SUM.sumReviews/rev_COUNT.totalUsers;
									cal_score = cal_score.toFixed(1);
									res.render('tours/propDetails', {prop: results,rating: cal_score,userTotal: rev_COUNT.totalUsers,userRev: rev_USER.rating,isFav: 0});
								}else{
									res.send("Wrong insert");
								}
							});
			
						}else{
							res.send("Wrong propDetails");
						}
					});
				}else{
					res.send("Review insert Fail");
				}
			});
		}
		else if(updateRev != null)
		{
			var review = {
				user: req.session.curr_uname,
				prop_id: updateRev,
				score: score
			};

			revpropModel.update(review, function(status){
				if(status){
					propModel.getByProp(updateRev, function(results){
						if(results.length > 0){
			
							var revCheck = {
								name: results[0].name,
								u_name: req.session.curr_uname
							}
			
							revpropModel.getReview( revCheck, function(rev_COUNT,rev_SUM,rev_USER){
								if(rev_COUNT.totalUsers != 0){
									var cal_score = rev_SUM.sumReviews/rev_COUNT.totalUsers;
									cal_score = cal_score.toFixed(1);
									res.render('tours/propDetails', {prop: results,rating: cal_score,userTotal: rev_COUNT.totalUsers,userRev: rev_USER.rating,isFav: 0});
								}else{
									res.send("Wrong update");
								}
							});
			
						}else{
							res.send("Wrong propDetails");
						}
					});
				}else{
					res.send("Review update Fail");
				}
			});
		}
		else if(back != null)
		{
			tour_id = req.session.tourId;
			
			tourModel.getById(tour_id, function(results){
				if(results.length > 0){
					res.render('tours/property', {tour: results});
				}else{
					res.send("Wrong property");
				}
			});
		}

});

module.exports = router;

