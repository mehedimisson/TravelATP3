var express 	= require('express');
var router 		= express.Router();
var cusModel	= require.main.require('./models/cus-model');
var revagentModel	= require.main.require('./models/revagent-model');
var favModel	= require.main.require('./models/fav-model');

router.get('/', function(req, res){
	
	console.log('Agents page requested!');

	cusModel.getAll(function(results){
		if(results.length > 0){
			res.render('agents/index', {agentlist: results});
		}else{
			res.send("Wrong index");
		}
	});

});

router.post('/rev', function(req, res){

	var review = {
		user: req.session.curr_uname,
		prop_id: req.body.reviewBtn,
		prop_name: req.body.hidval,
		score: req.body.rev_num
	};

	revagentModel.insert(review, function(status){
		if(status){
			cusModel.getById( req.body.reviewBtn, function(results){
				if(results != null){
	
					var revCheck = {
						name: results.name,
						u_name: req.session.curr_uname
					}
	
					revagentModel.getReview( revCheck, function(rev_COUNT,rev_SUM,rev_USER){
						if(rev_COUNT.totalUsers != 0){
							var cal_score = rev_SUM.sumReviews/rev_COUNT.totalUsers;
							cal_score = cal_score.toFixed(1);

							var temp1;
							if(rev_USER == null)
							{
								temp1 = 0;
							}
							else
							{
								temp1 = rev_USER.rating;
							}
	
							res.render('agents/profile', {agent_info: results,rating: cal_score,userTotal: rev_COUNT.totalUsers,userRev: temp1,isFav: 0});
						}else{
							res.render('agents/profile', {agent_info: results,rating: 0,userTotal: rev_COUNT.totalUsers,userRev: 0,isFav: 0});
						}
					});
	
				}else{
					res.send("Wrong agentDetails");
				}
			});
		}else{
			res.send("Review insert Fail");
		}
	});
});

router.post('/update', function(req, res){

	var review = {
		user: req.session.curr_uname,
		prop_id: req.body.updateRev,
		score: req.body.rev_num
	};

	revagentModel.update(review, function(status){
		if(status){
			cusModel.getById( req.body.updateRev, function(results){
				if(results != null){
	
					var revCheck = {
						name: results.name,
						u_name: req.session.curr_uname
					}
	
					revagentModel.getReview( revCheck, function(rev_COUNT,rev_SUM,rev_USER){
						if(rev_COUNT.totalUsers != 0){
							var cal_score = rev_SUM.sumReviews/rev_COUNT.totalUsers;
							cal_score = cal_score.toFixed(1);

							console.log(rev_COUNT);
							console.log(rev_SUM);
							console.log(rev_USER);

							var temp1;
							if(rev_USER == null)
							{
								temp1 = 0;
							}
							else
							{
								temp1 = rev_USER.rating;
							}
	
							res.render('agents/profile', {agent_info: results,rating: cal_score,userTotal: rev_COUNT.totalUsers,userRev: temp1,isFav: 0});
						}else{
							res.render('agents/profile', {agent_info: results,rating: 0,userTotal: rev_COUNT.totalUsers,userRev: 0,isFav: 0});
						}
					});
	
				}else{
					res.send("Wrong agentDetails");
				}
			});
		}else{
			res.send("Review insert Fail");
		}
	});
});

router.post('/favor', function(req, res){
	
	var favInfo = {
		user: req.session.curr_uname,
		prop_id: req.body.favBtn,
		prop_name: req.body.hidval_2
	};
	// console.log(favInfo);
	
	favModel.favorAgent( favInfo, function(status,isFavored){
		if(status){
			cusModel.getById( req.body.favBtn, function(results){
				if(results != null){
	
					var revCheck = {
						name: results.name,
						u_name: req.session.curr_uname
					}

					console.log(isFavored);

					revagentModel.getReview( revCheck, function(rev_COUNT,rev_SUM,rev_USER){
						if(rev_COUNT.totalUsers != 0){
							var cal_score = rev_SUM.sumReviews/rev_COUNT.totalUsers;
							cal_score = cal_score.toFixed(1);

							var temp1;
							if(rev_USER == null)
							{
								temp1 = 0;
							}
							else
							{
								temp1 = rev_USER.rating;
							}
	
							res.render('agents/profile', {agent_info: results,rating: cal_score,userTotal: rev_COUNT.totalUsers,userRev: temp1,isFav: isFavored});
						}else{
							res.render('agents/profile', {agent_info: results,rating: 0,userTotal: rev_COUNT.totalUsers,userRev: 0,isFav: isFavored});
						}
					});
	
				}else{
					res.send("Wrong favdetails");
				}
			});	
		}else{
			res.send("Wrong Favor");
		}
	});


});

router.post('/', function(req, res){

		var ag_id = req.body.viewBtn;

		cusModel.getById(ag_id, function(results){
			if(results != null){
	
				var revCheck = {
					name: results.name,
					u_name: req.session.curr_uname
				}

				revagentModel.getReview( revCheck, function(rev_COUNT,rev_SUM,rev_USER){
					if(rev_COUNT.totalUsers != 0){
						var cal_score = rev_SUM.sumReviews/rev_COUNT.totalUsers;
						cal_score = cal_score.toFixed(1);

						var temp1;
						if(rev_USER == null)
						{
							temp1 = 0;
						}
						else
						{
							temp1 = rev_USER.rating;
						}

						res.render('agents/profile', {agent_info: results,rating: cal_score,userTotal: rev_COUNT.totalUsers,userRev: temp1,isFav: 0});
					}else{
						res.render('agents/profile', {agent_info: results,rating: 0,userTotal: rev_COUNT.totalUsers,userRev: 0,isFav: 0});
					}
				});

			}else{
				res.send("Wrong profile");
			}
		});

});

module.exports = router;

