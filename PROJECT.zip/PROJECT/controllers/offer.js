var express 	= require('express');
var router 		= express.Router();
var offModel	= require.main.require('./models/offer-model');

router.get('/', function(req, res){
	console.log('Registration page requested!');
	res.render('offer/index');
});

router.post('/', function(req, res){
		
		var user ={
			name: req.body.name,
			price: req.body.price,
			tid: req.body.tid,
			sm: req.body.sm
		};

		offModel.insert(user, function(status){
			if(status){				
				res.redirect('/home');
			}else{
				res.redirect('/login');
			}
		});
});

module.exports = router;

