var express 	= require('express');
var router 		= express.Router();
var regModel	= require.main.require('./models/reg-model');

router.get('/', function(req, res){
	console.log('Registration page requested!');
	res.render('favs/index');
});

router.post('/', function(req, res){



});

module.exports = router;

