var express 	= require('express');
var router 		= express.Router();
var tourModel	= require.main.require('./models/tour-model');

router.get('/', function(req, res){
	
	console.log('tours page requested!');

	tourModel.getAll(function(results){
		if(results.length > 0){
			res.render('tours/index', {tourlist: results});
		}else{
			res.send("Wrong index");
		}
	});

});

router.post('/', function(req, res){

		var tour_id = req.body.viewBtn;
		req.session.tourId = tour_id;
		req.session.tourname = req.body.hidval;
		
		tourModel.getById(tour_id, function(results){
			if(results.length > 0){
				res.render('tours/property', {tour: results});
			}else{
				res.send("Wrong property");
			}
		});

});

module.exports = router;

