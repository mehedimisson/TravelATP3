var express 	= require('express');
var router 		= express.Router();
var regModel	= require.main.require('./models/reg-model');

router.get('/', function(req, res){
	console.log('Registration page requested!');
	res.render('reg/index');
});

router.post('/', function(req, res){
		
		var user ={
			name: req.body.name,
			uname: req.body.username,
			password: req.body.password,
			phn: req.body.phone,
			add: req.body.address,
			eml: req.body.email
		};

		regModel.insert(user, function(status){
			if(status){				
				res.redirect('/home');
			}else{
				res.redirect('/login');
			}
		});
});

module.exports = router;

