var express 	= require('express');
var router 		= express.Router();
var propModel	= require.main.require('./models/prop-model');
var revpropModel	= require.main.require('./models/revprop-model');

router.get('/', function(req, res){
	
	console.log('Property page requested!');


});

router.post('/', function(req, res){

		var p_id = req.body.viewBtn;

		propModel.getByProp(p_id, function(results){
			if(results.length > 0){

				var revCheck = {
					name: results[0].name,
					u_name: req.session.curr_uname
				}

				revpropModel.getReview( revCheck, function(rev_COUNT,rev_SUM,rev_USER){
					if(rev_COUNT.totalUsers != 0){
						
						var cal_score = rev_SUM.sumReviews/rev_COUNT.totalUsers;
						cal_score = cal_score.toFixed(1);

						var temp1;
						if(rev_USER == null)
						{
							temp1 = 0;
						}
						else
						{
							temp1 = rev_USER.rating;
						}
						// console.log(rev_USER);

						res.render('tours/propDetails', {prop: results,rating: cal_score,userTotal: rev_COUNT.totalUsers,userRev: temp1,isFav: 0});
					}else{
						res.render('tours/propDetails', {prop: results,rating: 0,userTotal: rev_COUNT.totalUsers,userRev: 0,isFav: 0});
					}
				});

			}else{
				res.send("Wrong propDetails");
			}
		});

});

module.exports = router;

