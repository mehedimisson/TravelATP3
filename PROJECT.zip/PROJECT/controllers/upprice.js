var express 	= require('express');
var router 		= express.Router();
var upModel	= require.main.require('./models/up-model');

router.get('/', function(req, res){
	console.log('Discount Page Requested !');
	res.render('upprice/index');
});

router.post('/', function(req, res){
		
		var user ={
			id: req.body.id
		};

		upModel.insert(user, function(status){
			if(status){				
				res.redirect('/home');
			}else{
				res.redirect('/upprice');
			}
		});
});

module.exports = router;

