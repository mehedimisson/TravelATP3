var express 	= require('express');
var router 		= express.Router();
var userModel	= require.main.require('./models/user-model');

router.get('/', function(req, res){
	console.log('profile page requested!');
	username = req.session.curr_uname;

	userModel.getById(username, function(results){
		if(results != null){
			res.render('profile/index', {userInfo: results});
		}else{
			res.send("Wrong index");
		}
	});
});

router.post('/update', function(req, res){
		
	var user ={
		uname : req.session.curr_uname,
		name: req.body.name,
		phn: req.body.phn,
		eml: req.body.eml
	};

	userModel.update(user, function(status){
		if(status){
			res.redirect('/profile');
		}else{
			res.send("Did not update");
		}
	});

});

router.post('/pass', function(req, res){

	res.render('profile/password');
	
});

router.post('/verifyPass', function(req, res){

	var user ={
		uname: req.session.curr_uname,
		password: req.body.password
	};

	userModel.verifyPassword(user, function(status){
		if(status){
			res.render('profile/newPassword');
		}else{

			res.render('profile/Password');
			console.log("Not Matched !");
		}
	});
	
});

router.post('/newPass', function(req, res){

	var user ={
		uname: req.session.curr_uname,
		password: req.body.password
	};

	userModel.confirmNewPassword(user, function(status){
		if(status){
			res.redirect('/profile');
		}else{
			res.send("Wrong newPass");
		}
	});
	
});

router.post('/dec', function(req, res){

	res.render('profile/deactivate');
	
});

router.get('/yes', function(req, res){

	var uname = req.session.curr_uname;

	userModel.deactivate(uname, function(status){
		if(status){
			res.redirect('/login');
		}else{
			res.send("Did not deactivate");
		}
	});

});

router.get('/no', function(req, res){
	res.redirect('/profile');
});

module.exports = router;

