//declaration
var express 		= require('express');
var bodyParser 		= require('body-parser');
var ejs 			= require('ejs');
var exSession 		= require('express-session');
var cookieParser 	= require('cookie-parser');

var reg 			= require('./controllers/reg');
var login 			= require('./controllers/login');
var logout 			= require('./controllers/logout');
var home 			= require('./controllers/home');
var agents 			= require('./controllers/agents');
var tours 			= require('./controllers/tours');
var property 		= require('./controllers/property');
var propDetails 	= require('./controllers/propDetails');
var bookings 		= require('./controllers/bookings');
var favs 			= require('./controllers/favs');
var history 			= require('./controllers/history');
var search 			= require('./controllers/search');
//var prod- 			= require('./controllers/search');
var upprice 			= require('./controllers/upprice');
var profile 			= require('./controllers/profile');
var offer 				= require('./controllers/offer');

var app = express();

// Configuration
app.set('view engine', 'ejs');

// Middleware

// For CSS & Images
app.use(express.static("zstyle"));
app.use(express.static("images"));

app.use(bodyParser.urlencoded({extended: false}));
app.use(exSession({secret: 'mysecret', saveUninitialized: true, resave: false}));
app.use(cookieParser());

app.use('/reg', reg);
app.use('/history', history);
app.use('/login', login);
app.use('/logout', logout);
app.use('/home', home);
app.use('/agents', agents);
app.use('/tours', tours);
app.use('/property', property);
app.use('/propDetails', propDetails);
app.use('/bookings', bookings);
app.use('/favs', favs);
app.use('/search', search);
app.use('/upprice', upprice);
app.use('/profile', profile);
app.use('/offer', offer);


//routes
app.get('/', function(req, res){
	res.redirect('/login');
});

//server startup
app.listen(3000, function(){
	console.log('server started at 3000!');
});

