-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2020 at 08:47 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tourandtravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `accbook`
--

CREATE TABLE `accbook` (
  `id` int(15) NOT NULL,
  `cusid` int(15) NOT NULL,
  `cusname` varchar(30) NOT NULL,
  `plid` int(15) NOT NULL,
  `username` varchar(140) NOT NULL,
  `plname` varchar(30) NOT NULL,
  `duration` int(5) NOT NULL,
  `cusemail` varchar(30) NOT NULL,
  `agemail` varchar(30) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accbook`
--

INSERT INTO `accbook` (`id`, `cusid`, `cusname`, `plid`, `username`, `plname`, `duration`, `cusemail`, `agemail`, `price`) VALUES
(1, 1, 'Tausif Anan', 0, 'misson', 'Keshabpur,Jossore', 3, 'tausifanan@gmail.com', 'missonplay@gmail.com', 500),
(2, 2, 'Sakib Chowdhury', 2, 'misson', 'Rome', 5, 'sakib@gmail.com', 'missonplay@gmail.com', 650),
(3, 3, 'Anik Islam', 2, 'nayeem', 'Rome', 2, 'anik@gmail.com', 'nayeemakbor@gmail.com', 600);

-- --------------------------------------------------------

--
-- Table structure for table `agent`
--

CREATE TABLE `agent` (
  `aid` int(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `address` varchar(100) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agent`
--

INSERT INTO `agent` (`aid`, `name`, `phone`, `email`, `username`, `password`, `address`, `status`) VALUES
(1, 'Mehedi Hassan Misson', '01722007980', 'missonplay@gmail.com', 'misson', 'misson2016', '1137 Nobodhara School Road, Vatara, Dhaka', 'deactivated'),
(2, 'Nayeem Akbor', '01515258919', 'nayeemakbor@gmail.com', 'nayeem', 'nayeem', 'Signboard,Narayanganj', 'active'),
(3, 'Shahadat Hossain Joy', '01688452369', 'joy@gmail.com', 'joy', 'joy', 'London,UK', 'active'),
(4, 'Rifat Khan', '01755986324', 'r@gmail.com', 'khan', 'khan', 'Narayanganj', 'active'),
(5, 'Farhan Haseen', '01755986324', 'rafi@gmail.com', 'rafi', 'rafi', 'Dhaka', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cusid` int(15) NOT NULL,
  `cusname` varchar(25) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(225) NOT NULL,
  `address` varchar(220) NOT NULL,
  `cuspic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cusid`, `cusname`, `phone`, `email`, `address`, `cuspic`) VALUES
(1, 'Tausif Anan', '01771888856', 'tausifanan@gmail.com', 'Nodda', 'anan.jpg'),
(2, 'Sakib Chowdhory', '01725964205', 'sakib@gmail.com', 'Rampura,Dhaka', 'sc.jpg'),
(3, 'Anik Islam', '01688523674', 'anik@gmail.com', 'Gopalganjg, Bangladesh', 'anik.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `favprop`
--

CREATE TABLE `favprop` (
  `id` int(99) NOT NULL,
  `u_name` varchar(55) NOT NULL,
  `p_id` int(99) NOT NULL,
  `p_name` varchar(55) NOT NULL,
  `status` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `favprop`
--

INSERT INTO `favprop` (`id`, `u_name`, `p_id`, `p_name`, `status`) VALUES
(1, 'misson', 1, 'Grand Hotel Villa Serbelloni, Bellagio', 'p'),
(2, 'misson', 1, 'Grand Hotel Villa Serbelloni, Bellagio', 'p'),
(3, 'misson', 3, 'Rosewood Castiglion del Bosco, Montalcino', 'p'),
(4, 'ron', 2, 'Palazzo Avino, Ravello', 'p');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `id` int(99) NOT NULL,
  `name` varchar(55) NOT NULL,
  `price` double NOT NULL,
  `propPic` varchar(55) NOT NULL,
  `tour_id` int(55) NOT NULL,
  `summary` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`id`, `name`, `price`, `propPic`, `tour_id`, `summary`) VALUES
(3, 'Rosewood Castiglion del Bosco, Montalcino', 432.56, 'ste.jpg', 1, 'Remodeled to perfection! This beautiful home is located close to shopping and dining. Here are just a few of its wonderful features: cozy fireplace, new kitchen cabinets, stainless steel sink, modern quartz counter tops, wood flooring, remodeled bathrooms, freshly painted, central a/c, attached two-car garage, large back yard, and so much more!'),
(4, 'General Walker Hotel, Monaco', 500.49, 'outdoors.jpg', 2, 'Remodeled to perfection! This beautiful home is located close to shopping and dining. Here are just a few of its wonderful features: cozy fireplace, new kitchen cabinets, stainless steel sink, modern quartz counter tops, wood flooring, remodeled bathrooms, freshly painted, central a/c, attached two-car garage, large back yard, and so much more!'),
(5, 'Grand Hotel Heiligendamm, Paris', 700, 'Munich.jpg', 2, 'Gorgeous 4-bedroom, 2-bathroom home in beautiful Silver Lake. This property offers 1,160 square feet of living space and a lot size of 5,499 square feet. Your family and loved ones will enjoy the spacious backyard, perfect for family gatherings! Come and take a look at this beauty....Don''t miss out!'),
(6, 'Excelsior Hotel Ernst, Sienne', 650.49, 'Berlin.jpg', 2, 'Elegant custom home offers unparalleled craftsmanship and exceptional amenities! This French inspired design is truly remarkable inside and out. Features include cherry cabinets, quartz counter tops, crown molding, custom windows provide plenty of natural lighting, expansive decking (1000 sq. ft.), gourmet kitchen with island (great for entertaining), gorgeous master suite, den, storage, plus STUNNING views of L.A. Basin and Downtown L.A. High demand area.'),
(7, 'Canis Resort, Freising', 500.75, 'Munich.jpg', 3, 'Gorgeous 4-bedroom, 2-bathroom home in beautiful Silver Lake. This property offers 1,160 square feet of living space and a lot size of 5,499 square feet. Your family and loved ones will enjoy the spacious backyard, perfect for family gatherings! Come and take a look at this beauty....Don''t miss out!'),
(8, 'Dom-Hotel, Cologne', 599.99, 'cityscape.jpg', 3, 'Remodeled to perfection! This beautiful home is located close to shopping and dining. Here are just a few of its wonderful features: cozy fireplace, new kitchen cabinets, stainless steel sink, modern quartz counter tops, wood flooring, remodeled bathrooms, freshly painted, central a/c, attached two-car garage, large back yard, and so much more!'),
(10, 'Hotel Sea Palace', 450, '', 1, 'Onk shundor hotel deikha lon baiccha lon');

-- --------------------------------------------------------

--
-- Table structure for table `reqbook`
--

CREATE TABLE `reqbook` (
  `rid` int(11) NOT NULL,
  `cid` int(5) NOT NULL,
  `cname` varchar(200) NOT NULL,
  `place` varchar(200) NOT NULL,
  `duration` int(5) NOT NULL,
  `phn` varchar(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `price` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reqbook`
--

INSERT INTO `reqbook` (`rid`, `cid`, `cname`, `place`, `duration`, `phn`, `email`, `price`) VALUES
(1, 1, 'Tausif Anan', 'Keshabpur,Jossore', 3, '01771888856', 'ta@gmail.com', 4),
(2, 2, 'Sakib Chowdhury', 'Rome', 5, '01725698025', 'sakib@gmail.com', 500);

-- --------------------------------------------------------

--
-- Table structure for table `revcustomer`
--

CREATE TABLE `revcustomer` (
  `id` int(99) NOT NULL,
  `username` varchar(55) NOT NULL,
  `cusid` int(55) NOT NULL,
  `cusname` varchar(55) NOT NULL,
  `rating` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `revcustomer`
--

INSERT INTO `revcustomer` (`id`, `username`, `cusid`, `cusname`, `rating`) VALUES
(1, 'jim', 1, 'Alan Grain', 3),
(2, 'jub', 1, 'Alan Grain', 4),
(3, 'ron', 1, 'Alan Grain', 2),
(4, 'kyo', 1, 'Alan Grain', 5),
(5, 'jim', 2, 'Kim Paul', 3);

-- --------------------------------------------------------

--
-- Table structure for table `revprop`
--

CREATE TABLE `revprop` (
  `id` int(99) NOT NULL,
  `u_name` varchar(55) NOT NULL,
  `p_id` int(99) NOT NULL,
  `p_name` varchar(55) NOT NULL,
  `rating` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `revprop`
--

INSERT INTO `revprop` (`id`, `u_name`, `p_id`, `p_name`, `rating`) VALUES
(1, 'jim', 2, 'Palazzo Avino, Ravello', 3),
(2, 'ron', 2, 'Palazzo Avino, Ravello', 3),
(3, 'jub', 2, 'Palazzo Avino, Ravello', 3),
(4, 'kyo', 2, 'Palazzo Avino, Ravello', 2),
(5, 'jim', 4, 'General Walker Hotel, Monaco', 1),
(6, 'jim', 1, 'Grand Hotel Villa Serbelloni, Bellagio', 5),
(7, 'ron', 1, 'Grand Hotel Villa Serbelloni, Bellagio', 3),
(8, 'jim', 3, 'Rosewood Castiglion del Bosco, Montalcino', 4),
(9, 'undefined', 1, 'Grand Hotel Villa Serbelloni, Bellagio', 5),
(10, 'undefined', 1, 'Grand Hotel Villa Serbelloni, Bellagio', 5),
(11, 'undefined', 2, 'Palazzo Avino, Ravello', 5),
(12, 'misson', 1, 'Grand Hotel Villa Serbelloni, Bellagio', 5),
(13, 'misson', 2, 'Palazzo Avino, Ravello', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tours`
--

CREATE TABLE `tours` (
  `id` int(99) NOT NULL,
  `name` varchar(70) NOT NULL,
  `tourPic` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tours`
--

INSERT INTO `tours` (`id`, `name`, `tourPic`) VALUES
(1, 'Italian tour', 'Venezia.jpg'),
(2, 'French tour', 'ste.jpg'),
(3, 'Germany tour', 'Berlin.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accbook`
--
ALTER TABLE `accbook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cusid`);

--
-- Indexes for table `favprop`
--
ALTER TABLE `favprop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reqbook`
--
ALTER TABLE `reqbook`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `revcustomer`
--
ALTER TABLE `revcustomer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `revprop`
--
ALTER TABLE `revprop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tours`
--
ALTER TABLE `tours`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accbook`
--
ALTER TABLE `accbook`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `agent`
--
ALTER TABLE `agent`
  MODIFY `aid` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cusid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `favprop`
--
ALTER TABLE `favprop`
  MODIFY `id` int(99) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `id` int(99) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `reqbook`
--
ALTER TABLE `reqbook`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `revcustomer`
--
ALTER TABLE `revcustomer`
  MODIFY `id` int(99) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `revprop`
--
ALTER TABLE `revprop`
  MODIFY `id` int(99) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tours`
--
ALTER TABLE `tours`
  MODIFY `id` int(99) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
